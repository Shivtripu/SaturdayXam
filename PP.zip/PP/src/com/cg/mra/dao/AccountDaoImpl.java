package com.cg.mra.dao;


import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNo;


public class AccountDaoImpl implements AccountDao {
	Map<String,Account> accountEntry;
	
	
	//insert mobile number as key and account object as value and insert in hash map
	public AccountDaoImpl() {
		accountEntry=new HashMap<>();
		accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikash", 631));
		accountEntry.put("9010210132", new Account("Prepaid", "Anju", 521));
		accountEntry.put("9010210133", new Account("Prepaid", "Tushar", 632));	
	}
	
	
	
	
	
	//taking mobile number for input   
	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidMobileNo {
		if(accountEntry.containsKey(mobileNo)) //check statement for mobile to key
		{
			return accountEntry.get(mobileNo);
		}
		throw new InvalidMobileNo("Mobile No Not Found");
	}

	
	//taking mobile number and rechargeamount for input  
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidMobileNo {
		Account acc=null;
		acc=getAccountDetails(mobileNo);
		if(acc!=null)
			{
			acc.setAccountBalance(acc.getAccountBalance()+rechargeAmount);
			return acc.getAccountBalance();
			}
		else
			throw new InvalidMobileNo("Mobile No Not Found");
		}
}
