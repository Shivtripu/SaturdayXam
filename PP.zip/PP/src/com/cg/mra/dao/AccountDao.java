package com.cg.mra.dao;
import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNo;

public interface AccountDao 
{
	public Account getAccountDetails(String mobileNo) throws InvalidMobileNo;
	public double rechargeAccount(String mobileNo,double rechargeAmount) throws InvalidMobileNo;
}
