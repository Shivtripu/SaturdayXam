package com.cg.mra.exception;


public class InvalidMobileNo extends Exception
{
	public InvalidMobileNo(String msg)
	{
		super(msg);
	}
	
}
