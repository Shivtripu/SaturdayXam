package com.cg.mra.ui;


import java.util.Scanner;

import com.cg.mra.exception.InvalidMobileNo;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class Main {

	public static void main(String[] args) {    //main method
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		AccountService accServ= new AccountServiceImpl();
		while(true)       //for loop
		{
			System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
			System.out.println("1. \t\t Account Balance Enquiry \n--------------------------------------------------------------------------------\n2. \t\t     Recharge Amount\n-------------------------------------------------------------------------------- \n3. \t\t          Exit");
			System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
			int choice=sc.nextInt();
			switch(choice)    //switch statement 
			{
			case 1:
				System.out.println("\t Enter the mobile number:"); 
				//taking mobile number for input   
				String mNo=sc.next();
				try {
					System.out.println(accServ.getAccountDetails(mNo));
				} catch (InvalidMobileNo e) {
					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("\t       Enter the mobile number:");
				String mbNo=sc.next();
				System.out.println("\t       Enter Recharge Amount");
				double rechargeAmount=sc.nextDouble();
				try {
					//taking mobile number and rechargeamount for input  
					System.out.println("\t----------\n       your account balance is "+ accServ.rechargeAccount(mbNo, rechargeAmount));
				} catch (InvalidMobileNo e) {
					e.printStackTrace();
				} 
				break;
			case 3:
				System.out.println("TANHKS");
				System.exit(0);
			}
		}
	}
}
