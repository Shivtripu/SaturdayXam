package com.cg.mra.test;
import static org.junit.Assert.*;

import org.junit.Before;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNo;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
public class MyTest {

	AccountService service;

	@Before
	public void setUp() {
		service = new AccountServiceImpl();
	}

	public void whenAccountDetailsIsSuccessfullyFettched() throws InvalidMobileNo {
		Account dummyAccount = new Account("Prepaid", "Vaishali", 200);
		assertEquals(dummyAccount, service.getAccountDetails("9010210131"));
	}

}
