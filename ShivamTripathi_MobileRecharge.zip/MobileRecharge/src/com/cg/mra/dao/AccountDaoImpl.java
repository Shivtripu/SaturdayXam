package com.cg.mra.dao;


import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidAmount;
import com.cg.mra.exception.InvalidMobileNo;


public class AccountDaoImpl implements AccountDao {
	Map<String,Account> accountEntry;
	
	public AccountDaoImpl() {
		accountEntry=new HashMap<>();
		// data entry for the hash map
		accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
		accountEntry.put("9010210132", new Account("Prepaid", "Anju", 521)); //the key that was given in paper was duplicate so i changed it to another unique 
		accountEntry.put("9010210133", new Account("Prepaid", "Tushar", 632));	//the key was similar so i changed it to unique. 
	}
	
	// overridden methods of AccountDao to get details
	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidMobileNo {
		if(accountEntry.containsKey(mobileNo)) //check statement for mobile to key
		{
			return accountEntry.get(mobileNo);  //will return the mobileNo
		}
		throw new InvalidMobileNo("Mobile No Not Found");  //Exception
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidMobileNo{
		Account acc=null;
		acc=getAccountDetails(mobileNo);
		
		if(acc!=null)
			{
			acc.setAccountBalance(acc.getAccountBalance()+rechargeAmount);
			return acc.getAccountBalance();
			}
		else
			throw new InvalidMobileNo("Mobile No Not Found");
		}
}
