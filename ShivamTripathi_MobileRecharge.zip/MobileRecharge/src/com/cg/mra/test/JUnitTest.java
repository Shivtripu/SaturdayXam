package com.cg.mra.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNo;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class JUnitTest {

	AccountService service;

	@Before
	public void setUp() {
		service = new AccountServiceImpl();
	}

	@Test
	public void whenAccountDetailsIsSuccessfullyFettched() throws InvalidMobileNo {
		service.rechargeAccount("9010210131", 50);
	}

	@Test()
	public void whenAccountDetailsIsSuccessfullyFettched1() throws InvalidMobileNo {
		service.rechargeAccount("9823920123", 200);

	}

	@Test()
	public void whenAccountDetailsIsSuccessfullyFettched3() throws InvalidMobileNo {
		service.rechargeAccount("9932012345", 50);
	}

	@Test()
	public void whenAccountDetailsIsSuccessfullyFettched4() throws InvalidMobileNo {
		service.rechargeAccount("9010210132", 50);
	}

	@Test()
	public void whenAccountDetailsIsSuccessfullyFettched5() throws InvalidMobileNo {
		service.rechargeAccount("9010210133", 500);
	}

}
