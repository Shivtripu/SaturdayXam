package com.cg.mra.exception;

public class InvalidAmount extends Exception{
	
	public InvalidAmount(String message)
	{
		super(message);
	}

}
