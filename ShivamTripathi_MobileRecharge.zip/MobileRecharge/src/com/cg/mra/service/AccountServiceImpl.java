package com.cg.mra.service;
import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.InvalidAmount;
import com.cg.mra.exception.InvalidMobileNo;

public class AccountServiceImpl implements AccountService 
{
	AccountDao accountdao=null;
	public AccountServiceImpl()
	{
		accountdao=new AccountDaoImpl();
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidMobileNo 
	{
		Account acc=accountdao.getAccountDetails(mobileNo);
		return acc;
	}

	@Override
	public double rechargeAccount(String mobileno, double rechargeAmount) throws InvalidMobileNo
	{
		double newamount=accountdao.rechargeAccount(mobileno, rechargeAmount);
		return newamount;
	}

}
